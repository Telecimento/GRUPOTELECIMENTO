# Instruções de Instalação - Sistema TeleCIMENTO

## 📋 Pré-requisitos

### Software Necessário
- **Python 3.11+** - [Download aqui](https://python.org/downloads)
- **Node.js 20+** - [Download aqui](https://nodejs.org)
- **Git** (opcional) - Para controle de versão

### Verificar Instalação
```bash
python --version    # Deve mostrar 3.11+
node --version      # Deve mostrar 20+
npm --version       # Deve mostrar 10+
```

## 🚀 Instalação Rápida

### Opção 1: Sistema Integrado (Recomendado)
O sistema já está configurado para rodar integrado (React + Flask).

1. **Extrair arquivos**
```bash
unzip telecimento_sistema_completo.zip
cd telecimento_project
```

2. **Configurar Backend**
```bash
cd backend/telecimento-api
python -m venv venv
source venv/bin/activate  # Linux/Mac
# ou
venv\Scripts\activate     # Windows
pip install -r requirements.txt
```

3. **Executar Sistema**
```bash
python src/main.py
```

4. **Acessar Sistema**
- Abra o navegador em: `http://localhost:5000`
- Sistema completo funcionando!

### Opção 2: Desenvolvimento Separado

#### Backend (Terminal 1)
```bash
cd backend/telecimento-api
source venv/bin/activate
python src/main.py
# Servidor rodando na porta 5000
```

#### Frontend (Terminal 2)
```bash
cd frontend/telecimento-app
npm install
npm run dev
# Servidor rodando na porta 5173
```

## 🔧 Configuração Detalhada

### 1. Configurar Banco de Dados
O banco SQLite já está configurado em `src/database/app.db`.

Para resetar o banco:
```bash
cd backend/telecimento-api/src
rm database/app.db
python main.py  # Criará novo banco automaticamente
```

### 2. Configurar Senha Administrativa
Edite o arquivo `backend/telecimento-api/src/models/evaluation.py`:

```python
# Linha ~200
admin_config = AdminConfig(
    password_hash=generate_password_hash("SUA_NOVA_SENHA"),
    # ...
)
```

### 3. Personalizar Informações da Empresa
Edite `frontend/telecimento-app/src/App.jsx`:

```javascript
// Seção do footer
<div className="company-info">
  <p>SEU_NOME_EMPRESA</p>
  <p>SEU_ENDERECO</p>
  <p>SEU_TELEFONE</p>
</div>
```

## 🌐 Deploy em Produção

### Preparar para Deploy
1. **Build do Frontend**
```bash
cd frontend/telecimento-app
npm run build
cp -r dist/* ../backend/telecimento-api/src/static/
```

2. **Configurar Servidor**
```bash
cd backend/telecimento-api
# Editar src/main.py
# Alterar debug=True para debug=False
# Alterar host='127.0.0.1' para host='0.0.0.0'
```

### Opções de Deploy

#### Heroku
```bash
# Criar Procfile na raiz do projeto backend
echo "web: python src/main.py" > Procfile

# Deploy
heroku create seu-app-telecimento
git push heroku main
```

#### Railway
1. Conecte seu repositório GitHub
2. Configure variável de ambiente: `PORT=5000`
3. Deploy automático

#### VPS/Servidor Próprio
```bash
# Instalar dependências no servidor
sudo apt update
sudo apt install python3 python3-pip nginx

# Configurar nginx (opcional)
# Usar gunicorn para produção
pip install gunicorn
gunicorn -w 4 -b 0.0.0.0:5000 src.main:app
```

## 🛠️ Solução de Problemas

### Erro: "Module not found"
```bash
# Reinstalar dependências
cd backend/telecimento-api
pip install -r requirements.txt

cd frontend/telecimento-app
npm install
```

### Erro: "Port already in use"
```bash
# Matar processo na porta
sudo lsof -t -i tcp:5000 | xargs kill -9  # Linux/Mac
netstat -ano | findstr :5000              # Windows
```

### Erro: "Database locked"
```bash
# Parar todos os processos Python
# Deletar arquivo de lock
rm backend/telecimento-api/src/database/app.db-wal
rm backend/telecimento-api/src/database/app.db-shm
```

### Frontend não carrega
1. Verificar se build foi copiado para `static/`
2. Verificar se Flask está servindo arquivos estáticos
3. Limpar cache do navegador (Ctrl+F5)

## 📁 Estrutura de Arquivos

```
telecimento_project/
├── README.md                    # Documentação principal
├── MANUAL_USUARIO.md           # Manual do usuário
├── INSTRUCOES_INSTALACAO.md    # Este arquivo
├── test_results.md             # Relatório de testes
├── frontend/
│   └── telecimento-app/        # Aplicação React
├── backend/
│   └── telecimento-api/        # API Flask
├── assets/                     # Imagens e recursos
├── design/                     # Documentação de design
└── database/                   # Backup do banco
```

## 🔐 Informações de Acesso

### Painel Administrativo
- **URL**: `http://localhost:5000` (clicar na engrenagem no rodapé)
- **Senha**: `@TELEcimento2025`

### Banco de Dados
- **Tipo**: SQLite
- **Localização**: `backend/telecimento-api/src/database/app.db`
- **Visualizar**: Use DB Browser for SQLite

## 📞 Suporte

### Problemas Técnicos
1. Verificar logs no terminal
2. Consultar seção "Solução de Problemas"
3. Verificar se todas as dependências estão instaladas

### Personalização
- **Cores**: Editar `frontend/telecimento-app/src/App.css`
- **Textos**: Editar `frontend/telecimento-app/src/App.jsx`
- **Logo**: Substituir arquivos em `assets/`

## ✅ Checklist de Instalação

- [ ] Python 3.11+ instalado
- [ ] Node.js 20+ instalado
- [ ] Arquivos extraídos
- [ ] Ambiente virtual criado
- [ ] Dependências Python instaladas
- [ ] Servidor Flask iniciado
- [ ] Sistema acessível em http://localhost:5000
- [ ] Login administrativo funcionando
- [ ] Avaliações sendo salvas no banco

---

**Sistema TeleCIMENTO - Instalação Completa!** 🎉

