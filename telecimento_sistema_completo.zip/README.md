# Sistema de Avaliação TeleCIMENTO

## Descrição

Sistema completo de avaliação de atendimento para a empresa TeleCIMENTO, desenvolvido com React (frontend) e Flask (backend), incluindo painel administrativo e controle de votação diária.

## Características Principais

### 🎨 Interface de Usuário
- **Tela de Carregamento**: Barra de progresso animada com placeholder para imagem personalizada
- **Design Responsivo**: Adaptável a desktop e mobile
- **Tema Corporativo**: Cores preto, amarelo e branco conforme identidade visual
- **Emojis Interativos**: Sistema de avaliação visual (Ruim, Regular, Bom, Excelente)

### 📊 Sistema de Avaliação
- **Seleção Múltipla**: Avaliação de setores VENDAS, CAIXA e EXPEDIÇÃO
- **Controle Diário**: Uma votação por dispositivo por dia
- **Comentários Opcionais**: Área de texto para feedback detalhado
- **Validação**: Verificação de campos obrigatórios

### 🔐 Painel Administrativo
- **Autenticação Segura**: Sistema de login com controle de tentativas
- **Estatísticas em Tempo Real**: Total de votos, mensagens e dispositivos
- **Ranking de Setores**: Classificação por desempenho
- **Exportação de Dados**: Download de relatórios em formato texto
- **Controles Administrativos**: Reset de votações e dados

### 🛡️ Segurança
- **Controle de Tentativas**: Bloqueio progressivo (5, 10, 15 tentativas)
- **Hash de Dados**: Proteção de informações sensíveis
- **Identificação de Dispositivos**: Controle único por device

### 💾 Banco de Dados
- **SQLite**: Banco local para desenvolvimento
- **Modelos Completos**: Avaliações, controle de votação, configurações admin
- **Estatísticas**: Armazenamento de métricas do sistema

## Estrutura do Projeto

```
telecimento_project/
├── frontend/
│   └── telecimento-app/          # Aplicação React
│       ├── src/
│       │   ├── App.jsx          # Componente principal
│       │   └── App.css          # Estilos personalizados
│       └── dist/                # Build de produção
├── backend/
│   └── telecimento-api/         # API Flask
│       ├── src/
│       │   ├── main.py          # Servidor principal
│       │   ├── models/          # Modelos do banco
│       │   ├── routes/          # Rotas da API
│       │   └── static/          # Frontend integrado
│       └── requirements.txt     # Dependências Python
├── assets/                      # Imagens e recursos
├── design/                      # Documentação de design
└── README.md                    # Este arquivo
```

## Tecnologias Utilizadas

### Frontend
- **React 18**: Framework JavaScript
- **Vite**: Build tool e dev server
- **Lucide React**: Ícones
- **CSS3**: Estilos personalizados

### Backend
- **Flask**: Framework web Python
- **SQLAlchemy**: ORM para banco de dados
- **SQLite**: Banco de dados
- **Flask-CORS**: Suporte a CORS

## Instalação e Execução

### Pré-requisitos
- Node.js 20+
- Python 3.11+
- npm ou yarn

### Desenvolvimento

1. **Clone o repositório**
```bash
git clone <repository-url>
cd telecimento_project
```

2. **Configure o Backend**
```bash
cd backend/telecimento-api
source venv/bin/activate
pip install -r requirements.txt
python src/main.py
```

3. **Configure o Frontend (desenvolvimento)**
```bash
cd frontend/telecimento-app
npm install
npm run dev
```

### Produção

1. **Build do Frontend**
```bash
cd frontend/telecimento-app
npm run build
```

2. **Copiar para Flask**
```bash
cp -r dist/* ../backend/telecimento-api/src/static/
```

3. **Executar Servidor Integrado**
```bash
cd backend/telecimento-api
source venv/bin/activate
python src/main.py
```

## Configuração

### Senha Administrativa
- **Padrão**: `@TELEcimento2025`
- **Localização**: `src/models/evaluation.py` (AdminConfig)

### Informações da Empresa
- **Nome**: TeleCIMENTO ALTERNATIVO
- **Endereço**: Av Manoel Caribé Filho, 3325, Canelas – Montes Claros
- **Telefone**: (38) 3212-8680
- **Instagram**: @grupotelecimento
- **WhatsApp**: Link personalizado

## API Endpoints

### Avaliações
- `POST /api/evaluations` - Enviar avaliação
- `GET /api/evaluations` - Listar avaliações (admin)
- `GET /api/check-vote-status/<device_id>` - Verificar status de votação

### Administração
- `POST /api/admin/login` - Login administrativo
- `GET /api/admin/statistics` - Estatísticas do sistema
- `POST /api/admin/reset-voting` - Resetar período de votação
- `POST /api/admin/reset-data` - Resetar todos os dados
- `GET /api/admin/export-data` - Exportar dados

## Funcionalidades Implementadas

### ✅ Requisitos Atendidos
- [x] Tela de carregamento com barra de progresso
- [x] Sistema de avaliação com emojis
- [x] Seleção múltipla de setores
- [x] Controle de votação diária
- [x] Painel administrativo completo
- [x] Sistema de autenticação seguro
- [x] Estatísticas e relatórios
- [x] Design responsivo
- [x] Integração frontend-backend
- [x] Banco de dados funcional
- [x] Exportação de dados
- [x] Sistema de fallback offline

### 🔄 Melhorias Futuras
- [ ] Integração com banco de dados em nuvem
- [ ] Sistema de notificações
- [ ] Dashboard avançado com gráficos
- [ ] API de relatórios mais robusta
- [ ] Autenticação multi-usuário

## Deploy

### Desenvolvimento Local
```bash
# Backend na porta 5000
python src/main.py

# Frontend integrado disponível em http://localhost:5000
```

### Produção
O sistema está preparado para deploy em plataformas como:
- Heroku
- Vercel
- Railway
- DigitalOcean

## Suporte

Para suporte técnico ou dúvidas sobre o sistema, consulte a documentação técnica ou entre em contato com a equipe de desenvolvimento.

## Licença

Sistema desenvolvido exclusivamente para TeleCIMENTO ALTERNATIVO.

---

**Desenvolvido com ❤️ para TeleCIMENTO**

