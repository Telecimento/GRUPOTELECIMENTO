from flask import Blueprint, request, jsonify
from datetime import datetime, date, timedelta
import json
import hashlib
from src.models.evaluation import db, Evaluation, AdminConfig, Statistics, VotingControl

evaluation_bp = Blueprint('evaluation', __name__)

@evaluation_bp.route('/evaluations', methods=['POST'])
def submit_evaluation():
    """Submete uma nova avaliação"""
    try:
        data = request.get_json()
        
        # Validar dados obrigatórios
        if not data or not data.get('sectors') or not data.get('rating') or not data.get('deviceId'):
            return jsonify({'error': 'Dados obrigatórios não fornecidos'}), 400
        
        device_id = data['deviceId']
        sectors = data['sectors']
        rating = data['rating']
        comment = data.get('comment', '').strip()
        
        # Verificar se já votou hoje
        today = date.today()
        device_hash = hashlib.sha256(device_id.encode()).hexdigest()
        
        existing_vote = VotingControl.query.filter_by(device_id_hash=device_hash).first()
        if existing_vote and existing_vote.last_vote_date == today:
            return jsonify({'error': 'Você já votou hoje. Tente novamente amanhã.'}), 429
        
        # Obter informações da requisição
        ip_address = request.remote_addr
        user_agent = request.headers.get('User-Agent', '')
        
        # Criar nova avaliação
        evaluation = Evaluation(
            device_id=device_id,
            sectors=json.dumps(sectors),
            rating=rating,
            comment=comment if comment else None,
            ip_address=ip_address,
            user_agent=user_agent
        )
        
        db.session.add(evaluation)
        
        # Atualizar controle de votação
        if existing_vote:
            existing_vote.last_vote_date = today
            existing_vote.vote_count += 1
        else:
            vote_control = VotingControl(device_id, today)
            db.session.add(vote_control)
        
        # Atualizar estatísticas
        stats = Statistics.query.first()
        if not stats:
            stats = Statistics()
            db.session.add(stats)
        
        stats.total_votes += 1
        if comment:
            stats.total_messages += 1
        
        db.session.commit()
        
        return jsonify({
            'message': 'Avaliação enviada com sucesso!',
            'evaluation_id': evaluation.id
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Erro interno do servidor: {str(e)}'}), 500

@evaluation_bp.route('/evaluations', methods=['GET'])
def get_evaluations():
    """Retorna todas as avaliações (apenas para admin)"""
    try:
        # Verificar autenticação admin (simplificado para desenvolvimento)
        auth_header = request.headers.get('Authorization')
        if not auth_header or not auth_header.startswith('Bearer '):
            return jsonify({'error': 'Token de autenticação necessário'}), 401
        
        evaluations = Evaluation.query.order_by(Evaluation.created_at.desc()).all()
        return jsonify([eval.to_dict() for eval in evaluations]), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno do servidor: {str(e)}'}), 500

@evaluation_bp.route('/admin/login', methods=['POST'])
def admin_login():
    """Autentica administrador"""
    try:
        data = request.get_json()
        if not data or not data.get('password'):
            return jsonify({'error': 'Senha não fornecida'}), 400
        
        password = data['password']
        
        # Buscar configuração do admin
        admin_config = AdminConfig.query.first()
        if not admin_config:
            # Criar configuração inicial com senha padrão
            admin_config = AdminConfig('@TELEcimento2025')
            db.session.add(admin_config)
            db.session.commit()
        
        # Verificar se está bloqueado
        now = datetime.utcnow()
        if admin_config.blocked_until and now < admin_config.blocked_until:
            remaining_time = admin_config.blocked_until - now
            return jsonify({
                'error': 'Acesso bloqueado',
                'blocked_until': admin_config.blocked_until.isoformat(),
                'remaining_seconds': int(remaining_time.total_seconds())
            }), 423
        
        # Verificar senha
        if admin_config.check_password(password):
            # Login bem-sucedido - resetar tentativas
            admin_config.login_attempts = 0
            admin_config.blocked_until = None
            db.session.commit()
            
            return jsonify({
                'message': 'Login realizado com sucesso',
                'token': 'admin_authenticated',  # Token simplificado para desenvolvimento
                'admin_id': admin_config.id
            }), 200
        else:
            # Senha incorreta - incrementar tentativas
            admin_config.login_attempts += 1
            
            # Definir bloqueio baseado no número de tentativas
            if admin_config.login_attempts >= 15:
                # Bloqueio permanente (1 ano)
                admin_config.blocked_until = now + timedelta(days=365)
                message = 'Muitas tentativas incorretas. Acesso bloqueado permanentemente.'
            elif admin_config.login_attempts >= 10:
                # Bloqueio de 2 horas
                admin_config.blocked_until = now + timedelta(hours=2)
                message = 'Muitas tentativas incorretas. Acesso bloqueado por 2 horas.'
            elif admin_config.login_attempts >= 5:
                # Bloqueio de 5 minutos
                admin_config.blocked_until = now + timedelta(minutes=5)
                message = 'Muitas tentativas incorretas. Acesso bloqueado por 5 minutos.'
            else:
                message = f'Senha incorreta. Tentativas restantes: {15 - admin_config.login_attempts}'
            
            db.session.commit()
            
            return jsonify({
                'error': message,
                'attempts': admin_config.login_attempts,
                'blocked_until': admin_config.blocked_until.isoformat() if admin_config.blocked_until else None
            }), 401
            
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Erro interno do servidor: {str(e)}'}), 500

@evaluation_bp.route('/admin/statistics', methods=['GET'])
def get_statistics():
    """Retorna estatísticas do sistema"""
    try:
        # Verificar autenticação admin
        auth_header = request.headers.get('Authorization')
        if not auth_header or not auth_header.startswith('Bearer '):
            return jsonify({'error': 'Token de autenticação necessário'}), 401
        
        # Buscar estatísticas
        stats = Statistics.query.first()
        if not stats:
            stats = Statistics()
            db.session.add(stats)
            db.session.commit()
        
        # Calcular estatísticas por setor
        evaluations = Evaluation.query.all()
        sector_stats = {
            'vendas': {'ruim': 0, 'regular': 0, 'bom': 0, 'excelente': 0, 'total': 0},
            'caixa': {'ruim': 0, 'regular': 0, 'bom': 0, 'excelente': 0, 'total': 0},
            'expedicao': {'ruim': 0, 'regular': 0, 'bom': 0, 'excelente': 0, 'total': 0}
        }
        
        for evaluation in evaluations:
            sectors = json.loads(evaluation.sectors)
            rating = evaluation.rating
            
            for sector in sectors:
                if sector in sector_stats:
                    sector_stats[sector][rating] += 1
                    sector_stats[sector]['total'] += 1
        
        # Calcular ranking dos setores
        sector_ranking = []
        for sector, stats_data in sector_stats.items():
            if stats_data['total'] > 0:
                # Calcular pontuação média (ruim=1, regular=2, bom=3, excelente=4)
                score = (
                    stats_data['ruim'] * 1 +
                    stats_data['regular'] * 2 +
                    stats_data['bom'] * 3 +
                    stats_data['excelente'] * 4
                ) / stats_data['total']
                
                sector_ranking.append({
                    'sector': sector,
                    'score': round(score, 2),
                    'total_votes': stats_data['total'],
                    'stats': stats_data
                })
        
        # Ordenar por pontuação
        sector_ranking.sort(key=lambda x: x['score'], reverse=True)
        
        # Contar dispositivos únicos
        unique_devices = VotingControl.query.count()
        
        return jsonify({
            'general_stats': stats.to_dict(),
            'sector_stats': sector_stats,
            'sector_ranking': sector_ranking,
            'unique_devices': unique_devices,
            'total_evaluations': len(evaluations)
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno do servidor: {str(e)}'}), 500

@evaluation_bp.route('/admin/reset-voting', methods=['POST'])
def reset_voting_period():
    """Reseta o período de votação permitindo que todos votem novamente"""
    try:
        # Verificar autenticação admin
        auth_header = request.headers.get('Authorization')
        if not auth_header or not auth_header.startswith('Bearer '):
            return jsonify({'error': 'Token de autenticação necessário'}), 401
        
        # Deletar todos os controles de votação
        VotingControl.query.delete()
        
        # Atualizar estatísticas
        stats = Statistics.query.first()
        if stats:
            stats.last_reset = datetime.utcnow()
        
        db.session.commit()
        
        return jsonify({'message': 'Período de votação resetado com sucesso'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Erro interno do servidor: {str(e)}'}), 500

@evaluation_bp.route('/admin/reset-data', methods=['POST'])
def reset_all_data():
    """Reseta todos os dados de avaliações e mensagens"""
    try:
        # Verificar autenticação admin
        auth_header = request.headers.get('Authorization')
        if not auth_header or not auth_header.startswith('Bearer '):
            return jsonify({'error': 'Token de autenticação necessário'}), 401
        
        # Deletar todas as avaliações e controles de votação
        Evaluation.query.delete()
        VotingControl.query.delete()
        
        # Resetar estatísticas
        stats = Statistics.query.first()
        if stats:
            stats.total_votes = 0
            stats.total_messages = 0
            stats.last_reset = datetime.utcnow()
        else:
            stats = Statistics()
            db.session.add(stats)
        
        db.session.commit()
        
        return jsonify({'message': 'Todos os dados foram resetados com sucesso'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f'Erro interno do servidor: {str(e)}'}), 500

@evaluation_bp.route('/admin/export-data', methods=['GET'])
def export_data():
    """Exporta dados em formato texto"""
    try:
        # Verificar autenticação admin
        auth_header = request.headers.get('Authorization')
        if not auth_header or not auth_header.startswith('Bearer '):
            return jsonify({'error': 'Token de autenticação necessário'}), 401
        
        # Buscar todas as avaliações
        evaluations = Evaluation.query.order_by(Evaluation.created_at.desc()).all()
        
        # Gerar relatório em texto
        report_lines = [
            "=== RELATÓRIO DE AVALIAÇÕES - TeleCIMENTO ===",
            f"Gerado em: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}",
            "",
            "INFORMAÇÕES DA EMPRESA:",
            "TeleCIMENTO ALTERNATIVO",
            "Endereço: Av Manoel Caribé Filho, 3325, Canelas – Montes Claros",
            "Celular: (38) 3212-8680",
            "",
            f"TOTAL DE AVALIAÇÕES: {len(evaluations)}",
            ""
        ]
        
        # Estatísticas por setor
        sector_stats = {
            'vendas': {'ruim': 0, 'regular': 0, 'bom': 0, 'excelente': 0},
            'caixa': {'ruim': 0, 'regular': 0, 'bom': 0, 'excelente': 0},
            'expedicao': {'ruim': 0, 'regular': 0, 'bom': 0, 'excelente': 0}
        }
        
        for evaluation in evaluations:
            sectors = json.loads(evaluation.sectors)
            rating = evaluation.rating
            
            for sector in sectors:
                if sector in sector_stats:
                    sector_stats[sector][rating] += 1
        
        report_lines.extend([
            "ESTATÍSTICAS POR SETOR:",
            ""
        ])
        
        for sector, stats in sector_stats.items():
            total = sum(stats.values())
            if total > 0:
                report_lines.extend([
                    f"SETOR: {sector.upper()}",
                    f"  Total de votos: {total}",
                    f"  Ruim: {stats['ruim']} ({stats['ruim']/total*100:.1f}%)",
                    f"  Regular: {stats['regular']} ({stats['regular']/total*100:.1f}%)",
                    f"  Bom: {stats['bom']} ({stats['bom']/total*100:.1f}%)",
                    f"  Excelente: {stats['excelente']} ({stats['excelente']/total*100:.1f}%)",
                    ""
                ])
        
        # Detalhes das avaliações
        report_lines.extend([
            "DETALHES DAS AVALIAÇÕES:",
            ""
        ])
        
        for i, evaluation in enumerate(evaluations, 1):
            sectors = json.loads(evaluation.sectors)
            report_lines.extend([
                f"AVALIAÇÃO #{i}",
                f"Data: {evaluation.created_at.strftime('%d/%m/%Y %H:%M:%S')}",
                f"Setores avaliados: {', '.join(sectors)}",
                f"Avaliação: {evaluation.rating}",
                f"Comentário: {evaluation.comment or 'Nenhum comentário'}",
                ""
            ])
        
        report_text = "\n".join(report_lines)
        
        return jsonify({
            'report': report_text,
            'filename': f'relatorio_telecimento_{datetime.now().strftime("%Y%m%d_%H%M%S")}.txt'
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno do servidor: {str(e)}'}), 500

@evaluation_bp.route('/check-vote-status/<device_id>', methods=['GET'])
def check_vote_status(device_id):
    """Verifica se o dispositivo já votou hoje"""
    try:
        today = date.today()
        device_hash = hashlib.sha256(device_id.encode()).hexdigest()
        
        existing_vote = VotingControl.query.filter_by(device_id_hash=device_hash).first()
        has_voted_today = existing_vote and existing_vote.last_vote_date == today
        
        return jsonify({
            'has_voted_today': has_voted_today,
            'last_vote_date': existing_vote.last_vote_date.isoformat() if existing_vote else None
        }), 200
        
    except Exception as e:
        return jsonify({'error': f'Erro interno do servidor: {str(e)}'}), 500

