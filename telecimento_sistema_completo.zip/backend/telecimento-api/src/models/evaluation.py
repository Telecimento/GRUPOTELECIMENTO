from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import hashlib

db = SQLAlchemy()

class Evaluation(db.Model):
    __tablename__ = 'evaluations'
    
    id = db.Column(db.Integer, primary_key=True)
    device_id_hash = db.Column(db.String(64), nullable=False)
    sectors = db.Column(db.Text, nullable=False)  # JSON string com setores selecionados
    rating = db.Column(db.String(20), nullable=False)  # ruim, regular, bom, excelente
    comment = db.Column(db.Text, nullable=True)
    ip_address = db.Column(db.String(45), nullable=True)
    user_agent_hash = db.Column(db.String(64), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __init__(self, device_id, sectors, rating, comment=None, ip_address=None, user_agent=None):
        self.device_id_hash = self._hash_string(device_id)
        self.sectors = sectors
        self.rating = rating
        self.comment = comment
        self.ip_address = ip_address
        if user_agent:
            self.user_agent_hash = self._hash_string(user_agent)
    
    def _hash_string(self, text):
        """Cria hash SHA-256 de uma string para privacidade"""
        return hashlib.sha256(text.encode()).hexdigest()
    
    def to_dict(self):
        return {
            'id': self.id,
            'sectors': self.sectors,
            'rating': self.rating,
            'comment': self.comment,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class AdminConfig(db.Model):
    __tablename__ = 'admin_config'
    
    id = db.Column(db.Integer, primary_key=True)
    password_hash = db.Column(db.String(64), nullable=False)
    login_attempts = db.Column(db.Integer, default=0)
    blocked_until = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __init__(self, password):
        self.password_hash = self._hash_password(password)
    
    def _hash_password(self, password):
        """Cria hash SHA-256 da senha"""
        return hashlib.sha256(password.encode()).hexdigest()
    
    def check_password(self, password):
        """Verifica se a senha está correta"""
        return self.password_hash == self._hash_password(password)
    
    def to_dict(self):
        return {
            'id': self.id,
            'login_attempts': self.login_attempts,
            'blocked_until': self.blocked_until.isoformat() if self.blocked_until else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class Statistics(db.Model):
    __tablename__ = 'statistics'
    
    id = db.Column(db.Integer, primary_key=True)
    total_votes = db.Column(db.Integer, default=0)
    total_messages = db.Column(db.Integer, default=0)
    connected_devices = db.Column(db.Integer, default=0)
    last_reset = db.Column(db.DateTime, default=datetime.utcnow)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'total_votes': self.total_votes,
            'total_messages': self.total_messages,
            'connected_devices': self.connected_devices,
            'last_reset': self.last_reset.isoformat() if self.last_reset else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

class VotingControl(db.Model):
    __tablename__ = 'voting_control'
    
    id = db.Column(db.Integer, primary_key=True)
    device_id_hash = db.Column(db.String(64), nullable=False, unique=True)
    last_vote_date = db.Column(db.Date, nullable=False)
    vote_count = db.Column(db.Integer, default=1)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __init__(self, device_id, vote_date):
        self.device_id_hash = hashlib.sha256(device_id.encode()).hexdigest()
        self.last_vote_date = vote_date
    
    def to_dict(self):
        return {
            'id': self.id,
            'last_vote_date': self.last_vote_date.isoformat() if self.last_vote_date else None,
            'vote_count': self.vote_count,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

