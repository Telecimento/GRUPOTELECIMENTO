# Documento de Design - TeleCIMENTO

## Visão Geral
Site de avaliação de serviços para a empresa TeleCIMENTO com sistema de votação diária, painel administrativo e integração com banco de dados.

## Paleta de Cores
- **Preto**: #000000 (cor principal, backgrounds)
- **Amarelo**: #FFD700 (destaques, botões, barra de progresso)
- **Branco**: #FFFFFF (textos, backgrounds secundários)
- **Cinza**: #808080 (texto "TELE" no título)

## Tipografia
- **Título Principal**: "TeleCIMENTO" - TELE em cinza, CIMENTO em branco
- **Fonte Principal**: Arial, sans-serif
- **Tamanhos**: 
  - Título: 48px
  - Subtítulos: 24px
  - Texto corpo: 16px

## Estrutura das Telas

### 1. Tela de Carregamento
- **Background**: Preto (#000000)
- **Elementos**:
  - Logo TeleCIMENTO centralizado
  - Barra de progresso amarela (#FFD700)
  - Detalhes decorativos em amarelo e branco
  - Espaço reservado para imagem personalizada (300x200px, centralizada acima do logo)
- **Animações**: Barra de progresso suave, fade-in dos elementos

### 2. Tela Principal (Sistema de Avaliação)
- **Background**: Vídeo de fundo com overlay escuro (opacity: 0.7)
- **Header**:
  - Título "TeleCIMENTO" (TELE cinza, CIMENTO branco)
  - Posicionamento: centralizado, topo da página
- **Sistema de Avaliação**:
  - Título: "Avalie o nosso atendimento"
  - Seleção múltipla de setores:
    - ☐ Setor de VENDAS
    - ☐ Setor de CAIXA  
    - ☐ Setor de EXPEDIÇÃO
  - Critérios de avaliação com emojis:
    - 😞 Ruim
    - 😐 Regular
    - 😊 Bom
    - 😍 Excelente
  - Área de comentários opcional (textarea)
  - Botão "Enviar Avaliação" (amarelo)
- **Footer**:
  - Informações da empresa
  - Links para Instagram e WhatsApp
  - Ícone de engrenagem (acesso admin) no canto inferior direito

### 3. Painel Administrativo
- **Acesso**: Ícone de engrenagem → senha @TELEcimento2025
- **Controle de Tentativas**:
  - 5 erros = 5 minutos bloqueado
  - 10 erros = 2 horas bloqueado
  - 15 erros = bloqueio permanente
- **Dashboard**:
  - Estatísticas gerais
  - Gráfico de ranking dos setores
  - Lista de avaliações recentes
  - Contador de dispositivos conectados
- **Funcionalidades**:
  - Botão "Voltar ao Site Principal"
  - Botão "Baixar Dados" (formato .txt)
  - Botão "Resetar Período de Votação"
  - Botão "Atualizar Dados"
  - Botão "Reiniciar Dados"
  - Gerenciamento de senhas administrativas

## Funcionalidades Técnicas

### Sistema de Votação
- **Limite**: 1 voto por dispositivo por dia
- **Reset**: Automático às 00:00 (horário de Brasília)
- **Identificação**: Por IP + User Agent + LocalStorage

### Banco de Dados (XAMPP/MySQL)
- **Tabelas**:
  - `avaliacoes` (id, setor, criterio, comentario, ip_hash, timestamp)
  - `admin_config` (id, senha_hash, tentativas_login, bloqueio_ate)
  - `estatisticas` (id, total_votos, dispositivos_conectados, data_reset)

### Responsividade
- **Desktop**: Layout em duas colunas
- **Tablet**: Layout adaptativo
- **Mobile**: Layout em coluna única, elementos empilhados

## Informações da Empresa
- **Nome**: TeleCIMENTO ALTERNATIVO
- **Endereço**: Av Manoel Caribé Filho, 3325, Canelas – Montes Claros
- **Celular**: (38) 3212-8680
- **Instagram**: https://www.instagram.com/grupotelecimento
- **WhatsApp**: Link personalizado fornecido

## Emojis Fixos para Avaliação
- 😞 **Ruim**: Vermelho escuro
- 😐 **Regular**: Laranja
- 😊 **Bom**: Verde claro  
- 😍 **Excelente**: Verde escuro

## Especificações de Imagem/Vídeo
- **Vídeo de fundo**: Suporte para MP4, WebM
- **Imagem de carregamento**: 300x200px, formatos JPG/PNG
- **Overlay de vídeo**: rgba(0,0,0,0.7) para escurecer
- **Ajuste automático**: object-fit: cover para qualquer tamanho

