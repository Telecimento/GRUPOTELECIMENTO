# Manual do Usuário - Sistema TeleCIMENTO

## Como Usar o Sistema de Avaliação

### Para Clientes (Avaliação)

#### 1. Acessando o Sistema
- Abra o navegador e acesse o site da TeleCIMENTO
- Aguarde o carregamento completo (barra de progresso)

#### 2. Fazendo uma Avaliação
1. **Selecione os Setores**: Marque os setores que deseja avaliar:
   - ☑️ Setor de VENDAS
   - ☑️ Setor de CAIXA  
   - ☑️ Setor de EXPEDIÇÃO

2. **Escolha sua Avaliação**: Clique no emoji que representa sua experiência:
   - 😞 **Ruim** - Atendimento insatisfatório
   - 😐 **Regular** - Atendimento mediano
   - 😊 **Bom** - Atendimento satisfatório
   - 🤩 **Excelente** - Atendimento excepcional

3. **Comentários (Opcional)**: Escreva detalhes sobre sua experiência

4. **Enviar**: Clique no botão amarelo "Enviar Avaliação"

#### 3. Regras Importantes
- ⏰ **Uma avaliação por dia**: Cada dispositivo pode votar apenas uma vez por dia
- 🔄 **Reset diário**: O sistema reseta às 00:00 (horário de Brasília)
- ✅ **Pelo menos um setor**: Deve selecionar ao menos um setor para avaliar
- ⭐ **Avaliação obrigatória**: Deve escolher um emoji de avaliação

### Para Administradores

#### 1. Acessando o Painel Administrativo
1. No rodapé do site, clique no ícone de engrenagem ⚙️
2. Digite a senha administrativa: `@TELEcimento2025`
3. Clique em "Entrar"

#### 2. Visualizando Estatísticas
O painel mostra:
- 📊 **Total de Votos**: Quantidade total de avaliações
- 💬 **Total de Mensagens**: Comentários recebidos
- 📱 **Dispositivos**: Número de dispositivos únicos
- 🏆 **Ranking**: Classificação dos setores por desempenho

#### 3. Ações Administrativas

##### Exportar Dados
- Clique em "Exportar Dados"
- Arquivo será baixado com todas as avaliações

##### Resetar Período de Votação
- Permite que dispositivos votem novamente
- Útil para testes ou situações especiais

##### Reiniciar Dados
- ⚠️ **CUIDADO**: Remove todas as avaliações permanentemente
- Use apenas quando necessário

#### 4. Segurança do Painel
- 🔐 **Controle de Tentativas**: Sistema bloqueia após tentativas incorretas
- ⏱️ **Bloqueios Progressivos**: 
  - 5 tentativas: Bloqueio de 1 minuto
  - 10 tentativas: Bloqueio de 5 minutos  
  - 15 tentativas: Bloqueio de 15 minutos

## Solução de Problemas

### Problemas Comuns

#### "Você já votou hoje"
- **Causa**: Dispositivo já fez uma avaliação hoje
- **Solução**: Aguarde até o próximo dia ou contate o administrador

#### "Erro ao enviar avaliação"
- **Causa**: Problema de conexão ou servidor
- **Solução**: Verifique a internet e tente novamente

#### "Selecione pelo menos um setor"
- **Causa**: Nenhum setor foi marcado
- **Solução**: Marque ao menos um setor antes de enviar

#### "Selecione uma avaliação"
- **Causa**: Nenhum emoji foi selecionado
- **Solução**: Clique em um dos emojis de avaliação

### Problemas do Painel Administrativo

#### "Senha incorreta"
- **Solução**: Verifique se está digitando `@TELEcimento2025` corretamente

#### "Muitas tentativas"
- **Solução**: Aguarde o tempo de bloqueio e tente novamente

#### Painel não carrega
- **Solução**: Atualize a página e tente fazer login novamente

## Contato e Suporte

### Informações da Empresa
- 📍 **Endereço**: Av Manoel Caribé Filho, 3325, Canelas – Montes Claros
- 📞 **Telefone**: (38) 3212-8680
- 📱 **Instagram**: @grupotelecimento
- 💬 **WhatsApp**: Disponível no site

### Suporte Técnico
Para problemas técnicos com o sistema:
1. Anote o erro exato que aparece
2. Informe o horário que ocorreu
3. Entre em contato pelos canais oficiais

## Dicas de Uso

### Para Melhores Resultados
- 🌐 Use navegadores atualizados (Chrome, Firefox, Safari)
- 📱 Sistema funciona em celulares e tablets
- 🔄 Mantenha a página atualizada
- 💾 Sistema salva dados automaticamente

### Privacidade
- 🔒 Suas avaliações são anônimas
- 📊 Dados são usados apenas para melhorar o atendimento
- 🛡️ Sistema protege informações dos usuários

---

**Sistema TeleCIMENTO - Sua opinião é importante para nós!**

