import { useState, useEffect } from 'react'
import { Settings, Instagram, MessageCircle, Phone, MapPin } from 'lucide-react'
import './App.css'

// Configuração da API
const API_BASE_URL = 'http://localhost:5000/api'

function App() {
  const [currentScreen, setCurrentScreen] = useState('loading')
  const [loadingProgress, setLoadingProgress] = useState(0)
  const [selectedSectors, setSelectedSectors] = useState([])
  const [selectedRating, setSelectedRating] = useState('')
  const [comment, setComment] = useState('')
  const [showLoginModal, setShowLoginModal] = useState(false)
  const [loginPassword, setLoginPassword] = useState('')
  const [loginError, setLoginError] = useState('')
  const [loginAttempts, setLoginAttempts] = useState(0)
  const [isBlocked, setIsBlocked] = useState(false)
  const [blockTimeRemaining, setBlockTimeRemaining] = useState(0)
  const [hasVotedToday, setHasVotedToday] = useState(false)
  const [authToken, setAuthToken] = useState('')
  const [adminStats, setAdminStats] = useState(null)
  const [isSubmitting, setIsSubmitting] = useState(false)

  // Simular carregamento
  useEffect(() => {
    if (currentScreen === 'loading') {
      const interval = setInterval(() => {
        setLoadingProgress(prev => {
          if (prev >= 100) {
            clearInterval(interval)
            setTimeout(() => setCurrentScreen('main'), 500)
            return 100
          }
          return prev + 2
        })
      }, 100)
      return () => clearInterval(interval)
    }
  }, [currentScreen])

  // Verificar status de votação ao carregar
  useEffect(() => {
    if (currentScreen === 'main') {
      checkVoteStatus()
    }
  }, [currentScreen])

  // Gerenciar bloqueio de login
  useEffect(() => {
    const blockUntil = localStorage.getItem('blockUntil')
    if (blockUntil) {
      const blockTime = new Date(blockUntil)
      const now = new Date()
      if (now < blockTime) {
        setIsBlocked(true)
        setBlockTimeRemaining(Math.ceil((blockTime - now) / 1000))
        
        const countdown = setInterval(() => {
          const remaining = Math.ceil((blockTime - new Date()) / 1000)
          if (remaining <= 0) {
            setIsBlocked(false)
            setBlockTimeRemaining(0)
            localStorage.removeItem('blockUntil')
            clearInterval(countdown)
          } else {
            setBlockTimeRemaining(remaining)
          }
        }, 1000)
        
        return () => clearInterval(countdown)
      } else {
        localStorage.removeItem('blockUntil')
      }
    }
  }, [])

  // Carregar estatísticas do admin
  useEffect(() => {
    if (currentScreen === 'admin' && authToken) {
      loadAdminStats()
    }
  }, [currentScreen, authToken])

  const sectors = [
    { id: 'vendas', label: 'Setor de VENDAS' },
    { id: 'caixa', label: 'Setor de CAIXA' },
    { id: 'expedicao', label: 'Setor de EXPEDIÇÃO' }
  ]

  const ratings = [
    { id: 'ruim', emoji: '😞', label: 'Ruim' },
    { id: 'regular', emoji: '😐', label: 'Regular' },
    { id: 'bom', emoji: '😊', label: 'Bom' },
    { id: 'excelente', emoji: '😍', label: 'Excelente' }
  ]

  const generateDeviceId = () => {
    let deviceId = localStorage.getItem('deviceId')
    if (!deviceId) {
      deviceId = 'device_' + Math.random().toString(36).substr(2, 9)
      localStorage.setItem('deviceId', deviceId)
    }
    return deviceId
  }

  const checkVoteStatus = async () => {
    try {
      const deviceId = generateDeviceId()
      const response = await fetch(`${API_BASE_URL}/check-vote-status/${deviceId}`)
      
      if (response.ok) {
        const data = await response.json()
        setHasVotedToday(data.has_voted_today)
      } else {
        // Se a API não estiver disponível, usar localStorage como fallback
        const lastVoteDate = localStorage.getItem('lastVoteDate')
        const today = new Date().toDateString()
        setHasVotedToday(lastVoteDate === today)
      }
    } catch (error) {
      console.error('Erro ao verificar status de votação:', error)
      // Fallback para localStorage
      const lastVoteDate = localStorage.getItem('lastVoteDate')
      const today = new Date().toDateString()
      setHasVotedToday(lastVoteDate === today)
    }
  }

  const handleSectorChange = (sectorId) => {
    setSelectedSectors(prev => 
      prev.includes(sectorId) 
        ? prev.filter(id => id !== sectorId)
        : [...prev, sectorId]
    )
  }

  const handleSubmitEvaluation = async () => {
    if (hasVotedToday) {
      alert('Você já votou hoje. Tente novamente amanhã.')
      return
    }

    if (selectedSectors.length === 0 || !selectedRating) {
      alert('Por favor, selecione pelo menos um setor e uma avaliação.')
      return
    }

    setIsSubmitting(true)

    try {
      const evaluationData = {
        sectors: selectedSectors,
        rating: selectedRating,
        comment: comment.trim(),
        deviceId: generateDeviceId()
      }

      const response = await fetch(`${API_BASE_URL}/evaluations`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(evaluationData)
      })

      if (response.ok) {
        const result = await response.json()
        
        // Marcar como votado hoje
        localStorage.setItem('lastVoteDate', new Date().toDateString())
        setHasVotedToday(true)
        
        // Limpar formulário
        setSelectedSectors([])
        setSelectedRating('')
        setComment('')
        
        alert('Avaliação enviada com sucesso! Obrigado pelo seu feedback.')
      } else {
        const error = await response.json()
        alert(error.error || 'Erro ao enviar avaliação. Tente novamente.')
      }
    } catch (error) {
      console.error('Erro ao enviar avaliação:', error)
      
      // Fallback: salvar localmente se API não estiver disponível
      localStorage.setItem('lastVoteDate', new Date().toDateString())
      setHasVotedToday(true)
      
      setSelectedSectors([])
      setSelectedRating('')
      setComment('')
      
      alert('Avaliação registrada localmente! Obrigado pelo seu feedback.')
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleAdminLogin = async () => {
    if (isBlocked) {
      const minutes = Math.floor(blockTimeRemaining / 60)
      const seconds = blockTimeRemaining % 60
      setLoginError(`Acesso bloqueado. Tente novamente em ${minutes}:${seconds.toString().padStart(2, '0')}`)
      return
    }

    try {
      const response = await fetch(`${API_BASE_URL}/admin/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ password: loginPassword })
      })

      const data = await response.json()

      if (response.ok) {
        setAuthToken(data.token)
        setCurrentScreen('admin')
        setShowLoginModal(false)
        setLoginPassword('')
        setLoginError('')
        setLoginAttempts(0)
        localStorage.removeItem('loginAttempts')
      } else {
        setLoginAttempts(data.attempts || 0)
        
        if (data.blocked_until) {
          const blockTime = new Date(data.blocked_until)
          const now = new Date()
          if (now < blockTime) {
            setIsBlocked(true)
            setBlockTimeRemaining(Math.ceil((blockTime - now) / 1000))
            localStorage.setItem('blockUntil', data.blocked_until)
          }
        }
        
        setLoginError(data.error)
        setLoginPassword('')
      }
    } catch (error) {
      console.error('Erro no login:', error)
      
      // Fallback para autenticação local
      if (loginPassword === '@TELEcimento2025') {
        setCurrentScreen('admin')
        setShowLoginModal(false)
        setLoginPassword('')
        setLoginError('')
        setLoginAttempts(0)
        localStorage.removeItem('loginAttempts')
      } else {
        const newAttempts = loginAttempts + 1
        setLoginAttempts(newAttempts)
        localStorage.setItem('loginAttempts', newAttempts.toString())
        
        let blockTime = 0
        let message = ''
        
        if (newAttempts >= 15) {
          localStorage.setItem('blockUntil', new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString())
          message = 'Muitas tentativas incorretas. Acesso bloqueado permanentemente.'
          setIsBlocked(true)
        } else if (newAttempts >= 10) {
          blockTime = 2 * 60 * 60 * 1000
          localStorage.setItem('blockUntil', new Date(Date.now() + blockTime).toISOString())
          message = 'Muitas tentativas incorretas. Acesso bloqueado por 2 horas.'
          setIsBlocked(true)
          setBlockTimeRemaining(blockTime / 1000)
        } else if (newAttempts >= 5) {
          blockTime = 5 * 60 * 1000
          localStorage.setItem('blockUntil', new Date(Date.now() + blockTime).toISOString())
          message = 'Muitas tentativas incorretas. Acesso bloqueado por 5 minutos.'
          setIsBlocked(true)
          setBlockTimeRemaining(blockTime / 1000)
        } else {
          message = `Senha incorreta. Tentativas restantes: ${15 - newAttempts}`
        }
        
        setLoginError(message)
        setLoginPassword('')
      }
    }
  }

  const loadAdminStats = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/admin/statistics`, {
        headers: {
          'Authorization': `Bearer ${authToken}`
        }
      })

      if (response.ok) {
        const data = await response.json()
        setAdminStats(data)
      } else {
        console.error('Erro ao carregar estatísticas')
        // Dados mock para fallback
        setAdminStats({
          general_stats: { total_votes: 0, total_messages: 0 },
          unique_devices: 1,
          sector_ranking: []
        })
      }
    } catch (error) {
      console.error('Erro ao carregar estatísticas:', error)
      // Dados mock para fallback
      setAdminStats({
        general_stats: { total_votes: 0, total_messages: 0 },
        unique_devices: 1,
        sector_ranking: []
      })
    }
  }

  const handleAdminAction = async (action) => {
    try {
      let endpoint = ''
      let method = 'POST'
      
      switch (action) {
        case 'reset-voting':
          endpoint = '/admin/reset-voting'
          break
        case 'reset-data':
          endpoint = '/admin/reset-data'
          break
        case 'export-data':
          endpoint = '/admin/export-data'
          method = 'GET'
          break
        case 'update-data':
          loadAdminStats()
          return
        default:
          return
      }

      const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        method,
        headers: {
          'Authorization': `Bearer ${authToken}`
        }
      })

      if (response.ok) {
        const data = await response.json()
        
        if (action === 'export-data') {
          // Criar e baixar arquivo
          const blob = new Blob([data.report], { type: 'text/plain' })
          const url = window.URL.createObjectURL(blob)
          const a = document.createElement('a')
          a.href = url
          a.download = data.filename
          document.body.appendChild(a)
          a.click()
          document.body.removeChild(a)
          window.URL.revokeObjectURL(url)
        } else {
          alert(data.message)
          loadAdminStats() // Recarregar estatísticas
        }
      } else {
        const error = await response.json()
        alert(error.error || 'Erro ao executar ação')
      }
    } catch (error) {
      console.error('Erro na ação admin:', error)
      alert('Erro ao executar ação. Verifique a conexão.')
    }
  }

  const formatTime = (seconds) => {
    const hours = Math.floor(seconds / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)
    const secs = seconds % 60
    
    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
    }
    return `${minutes}:${secs.toString().padStart(2, '0')}`
  }

  if (currentScreen === 'loading') {
    return (
      <div className="loading-screen">
        <div className="loading-image-placeholder">
          <span>Coloque sua imagem aqui<br/>(300x200px)</span>
        </div>
        <div className="loading-logo">
          <h1>
            <span className="tele">Tele</span>
            <span className="cimento">CIMENTO</span>
          </h1>
        </div>
        <div className="progress-bar">
          <div 
            className="progress-fill" 
            style={{ width: `${loadingProgress}%` }}
          ></div>
        </div>
        <div className="progress-text">{loadingProgress}%</div>
      </div>
    )
  }

  if (currentScreen === 'admin') {
    return (
      <div className="admin-panel">
        <div className="admin-header">
          <h1 className="admin-title">PAINEL ADMINISTRATIVO</h1>
          <button 
            className="back-button"
            onClick={() => setCurrentScreen('main')}
          >
            Voltar ao Site Principal
          </button>
        </div>
        
        <div className="stats-grid">
          <div className="stat-card">
            <div className="stat-title">Total de Votos</div>
            <div className="stat-value">{adminStats?.general_stats?.total_votes || 0}</div>
          </div>
          <div className="stat-card">
            <div className="stat-title">Mensagens Enviadas</div>
            <div className="stat-value">{adminStats?.general_stats?.total_messages || 0}</div>
          </div>
          <div className="stat-card">
            <div className="stat-title">Dispositivos Conectados</div>
            <div className="stat-value">{adminStats?.unique_devices || 0}</div>
          </div>
          <div className="stat-card">
            <div className="stat-title">Setor com Melhor Desempenho</div>
            <div className="stat-value">
              {adminStats?.sector_ranking?.[0]?.sector?.toUpperCase() || '-'}
            </div>
          </div>
        </div>

        {adminStats?.sector_ranking && adminStats.sector_ranking.length > 0 && (
          <div className="stat-card" style={{ marginTop: '2rem' }}>
            <div className="stat-title">Ranking dos Setores</div>
            {adminStats.sector_ranking.map((sector, index) => (
              <div key={sector.sector} style={{ 
                display: 'flex', 
                justifyContent: 'space-between', 
                padding: '0.5rem 0',
                borderBottom: '1px solid #333'
              }}>
                <span>{index + 1}º - {sector.sector.toUpperCase()}</span>
                <span>Nota: {sector.score}/4.0 ({sector.total_votes} votos)</span>
              </div>
            ))}
          </div>
        )}

        <div className="actions-section">
          <button 
            className="action-button"
            onClick={() => handleAdminAction('export-data')}
          >
            Baixar Dados
          </button>
          <button 
            className="action-button"
            onClick={() => handleAdminAction('reset-voting')}
          >
            Resetar Período de Votação
          </button>
          <button 
            className="action-button"
            onClick={() => handleAdminAction('update-data')}
          >
            Atualizar Dados
          </button>
          <button 
            className="action-button"
            onClick={() => handleAdminAction('reset-data')}
          >
            Reiniciar Dados
          </button>
          <button className="action-button">Gerenciar Senhas</button>
        </div>
      </div>
    )
  }

  return (
    <div className="main-screen">
      {/* Placeholder para vídeo de fundo */}
      <div className="video-background" style={{
        background: 'linear-gradient(45deg, #1a1a1a, #333333)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        color: '#666',
        fontSize: '1.2rem'
      }}>
        Vídeo de fundo será colocado aqui
      </div>
      <div className="video-overlay"></div>
      
      <div className="main-content">
        <h1 className="main-title">
          <span className="tele">Tele</span>
          <span className="cimento">CIMENTO</span>
        </h1>
        
        <div className="evaluation-form">
          <h2 className="evaluation-title">Avalie o nosso atendimento</h2>
          
          <div className="sectors-section">
            <h3 className="sectors-title">Selecione os setores que deseja avaliar:</h3>
            <div className="sector-checkboxes">
              {sectors.map(sector => (
                <label key={sector.id} className="sector-checkbox">
                  <input
                    type="checkbox"
                    checked={selectedSectors.includes(sector.id)}
                    onChange={() => handleSectorChange(sector.id)}
                    disabled={hasVotedToday || isSubmitting}
                  />
                  <span>{sector.label}</span>
                </label>
              ))}
            </div>
          </div>
          
          <div className="rating-section">
            <h3 className="rating-title">Como você avalia o atendimento?</h3>
            <div className="rating-options">
              {ratings.map(rating => (
                <div
                  key={rating.id}
                  className={`rating-option ${selectedRating === rating.id ? 'selected' : ''}`}
                  onClick={() => !hasVotedToday && !isSubmitting && setSelectedRating(rating.id)}
                  style={{ 
                    opacity: hasVotedToday || isSubmitting ? 0.5 : 1, 
                    cursor: hasVotedToday || isSubmitting ? 'not-allowed' : 'pointer' 
                  }}
                >
                  <div className="rating-emoji">{rating.emoji}</div>
                  <div className="rating-label">{rating.label}</div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="comment-section">
            <label className="comment-label">Comentários (opcional):</label>
            <textarea
              className="comment-textarea"
              placeholder="Conte-nos sobre sua experiência..."
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              disabled={hasVotedToday || isSubmitting}
            />
          </div>
          
          <button 
            className="submit-button"
            onClick={handleSubmitEvaluation}
            disabled={hasVotedToday || isSubmitting}
          >
            {isSubmitting ? 'Enviando...' : hasVotedToday ? 'Você já votou hoje' : 'Enviar Avaliação'}
          </button>
        </div>
      </div>
      
      <div className="footer">
        <div className="company-info">
          <div><strong>TeleCIMENTO ALTERNATIVO</strong></div>
          <div><MapPin size={16} style={{display: 'inline', marginRight: '4px'}} />Av Manoel Caribé Filho, 3325, Canelas – Montes Claros</div>
          <div><Phone size={16} style={{display: 'inline', marginRight: '4px'}} />(38) 3212-8680</div>
        </div>
        
        <div className="social-links">
          <a 
            href="https://www.instagram.com/grupotelecimento?igsh=amZwcHJkZTFhbDRj" 
            target="_blank" 
            rel="noopener noreferrer"
            className="social-link"
          >
            <Instagram size={20} style={{display: 'inline', marginRight: '4px'}} />
            Instagram
          </a>
          <a 
            href="https://falecomtelecimento.my.canva.site/fale-com-um-de-nossos-vendedores?fbclid=PAZXh0bgNhZW0CMTEAAafQODAX-g3IdWl6XileF1i43_goEbiBN636tiOKZsWIble5LfPP8tzTNAtbww_aem_apfU3IOjb7YbkUVs81PJjA" 
            target="_blank" 
            rel="noopener noreferrer"
            className="social-link"
          >
            <MessageCircle size={20} style={{display: 'inline', marginRight: '4px'}} />
            WhatsApp
          </a>
        </div>
        
        <button 
          className="admin-gear"
          onClick={() => setShowLoginModal(true)}
          title="Acesso Administrativo"
        >
          <Settings size={24} />
        </button>
      </div>
      
      {showLoginModal && (
        <div className="login-modal">
          <div className="login-form">
            <h2 className="login-title">Acesso Administrativo</h2>
            <input
              type="password"
              className="login-input"
              placeholder="Digite a senha"
              value={loginPassword}
              onChange={(e) => setLoginPassword(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleAdminLogin()}
              disabled={isBlocked}
            />
            <button 
              className="login-button"
              onClick={handleAdminLogin}
              disabled={isBlocked}
            >
              {isBlocked ? `Bloqueado (${formatTime(blockTimeRemaining)})` : 'Entrar'}
            </button>
            {loginError && <div className="login-error">{loginError}</div>}
            <div className="login-attempts">
              Tentativas: {loginAttempts}/15
            </div>
            <button 
              className="login-button"
              onClick={() => {
                setShowLoginModal(false)
                setLoginPassword('')
                setLoginError('')
              }}
              style={{ background: '#666', marginTop: '1rem' }}
            >
              Cancelar
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

export default App

